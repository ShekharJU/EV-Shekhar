"use client";

import React, { createContext, useContext, useState, useEffect } from "react";
import { EVData, processCSVData } from "../utils/processData";

interface EVDataContextType {
  data: EVData[];
  loading: boolean;
  error: string | null;
}

const EVDataContext = createContext<EVDataContextType>({
  data: [],
  loading: true,
  error: null,
});

export const useEVData = () => useContext(EVDataContext);

export const EVDataProvider = ({ children }: { children: React.ReactNode }) => {
  const [data, setData] = useState<EVData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        const response = await fetch("/data/ev_population.csv");
        const blob = await response.blob();
        const file = new File([blob], "ev_population.csv");
        const parsedData = await processCSVData(file);
        setData(parsedData);
      } catch (err) {
        setError("Failed to load EV data");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  return (
    <EVDataContext.Provider value={{ data, loading, error }}>
      {children}
    </EVDataContext.Provider>
  );
};
