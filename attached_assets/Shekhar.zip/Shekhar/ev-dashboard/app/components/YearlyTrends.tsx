"use client";

import { Card, Title, AreaChart } from "@tremor/react";
import { useEVData } from "../context/EVDataContext";
import { getYearlyTrends } from "../utils/processData";

const YearlyTrends = () => {
  const { data, loading, error } = useEVData();

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  const yearlyData = getYearlyTrends(data);

  return (
    <Card className="p-6 bg-white rounded-lg shadow">
      <Title className="text-lg font-medium text-gray-900 mb-4">
        Yearly EV Adoption Trends
      </Title>
      <div className="mt-4 h-[400px]">
        <AreaChart
          className="h-full"
          data={yearlyData}
          index="year"
          categories={["count", "avgRange"]}
          colors={["indigo", "emerald"]}
          valueFormatter={(number: number) => {
            if (number > 1000)
              return `${Math.round(number).toLocaleString()} miles`;
            return `${Math.round(number)} vehicles`;
          }}
          showLegend={true}
          showGridLines={true}
          startEndOnly={false}
          showXAxis={true}
          showYAxis={true}
          yAxisWidth={60}
        />
      </div>
    </Card>
  );
};

export default YearlyTrends;
