"use client";

import { BarChart } from "@tremor/react";
import { useEVData } from "../context/EVDataContext";
import { getTopMakes } from "../utils/processData";

const EVDistributionChart = () => {
  const { data, loading, error } = useEVData();

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  const chartData = getTopMakes(data);

  return (
    <BarChart
      className="mt-6"
      data={chartData}
      index="make"
      categories={["count"]}
      colors={["blue"]}
      yAxisWidth={48}
    />
  );
};

export default EVDistributionChart;
