"use client";

import { Card, Grid, Metric, Text, Title, ProgressBar } from "@tremor/react";
import { useEVData } from "../context/EVDataContext";
import { calculateStats } from "../utils/processData";

const EVStats = () => {
  const { data, loading, error } = useEVData();

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  const stats = calculateStats(data);

  // Calculate percentage of EVs by type
  const evTypes = data.reduce((acc, curr) => {
    acc[curr.ElectricVehicleType] = (acc[curr.ElectricVehicleType] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const totalVehicles = Object.values(evTypes).reduce((a, b) => a + b, 0);
  const evTypePercentages = Object.entries(evTypes).map(([type, count]) => ({
    type,
    percentage: Math.round((count / totalVehicles) * 100),
  }));

  return (
    <div className="space-y-6">
      <Grid numItemsLg={4} className="gap-6">
        <Card className="p-6 bg-white rounded-lg shadow hover:shadow-lg transition-shadow">
          <div className="flex flex-col space-y-1">
            <Text className="text-sm font-medium text-gray-500">Total EVs</Text>
            <Metric className="text-2xl font-bold text-gray-900">
              {stats.totalEVs.toLocaleString()}
            </Metric>
          </div>
        </Card>
        <Card className="p-6 bg-white rounded-lg shadow hover:shadow-lg transition-shadow">
          <div className="flex flex-col space-y-1">
            <Text className="text-sm font-medium text-gray-500">
              Average Electric Range
            </Text>
            <Metric className="text-2xl font-bold text-gray-900">
              {stats.avgRange} miles
            </Metric>
          </div>
        </Card>
        <Card className="p-6 bg-white rounded-lg shadow hover:shadow-lg transition-shadow">
          <div className="flex flex-col space-y-1">
            <Text className="text-sm font-medium text-gray-500">
              Average Base MSRP
            </Text>
            <Metric className="text-2xl font-bold text-gray-900">
              ${stats.avgMSRP.toLocaleString()}
            </Metric>
          </div>
        </Card>
        <Card className="p-6 bg-white rounded-lg shadow hover:shadow-lg transition-shadow">
          <div className="flex flex-col space-y-1">
            <Text className="text-sm font-medium text-gray-500">
              Most Common Make
            </Text>
            <Metric className="text-2xl font-bold text-gray-900">
              {stats.mostCommonMake}
            </Metric>
          </div>
        </Card>
      </Grid>

      <Card className="p-6 bg-white rounded-lg shadow">
        <Title className="text-lg font-medium text-gray-900 mb-4">
          Vehicle Type Distribution
        </Title>
        <div className="space-y-4">
          {evTypePercentages.map(({ type, percentage }) => (
            <div key={type} className="space-y-2">
              <div className="flex items-center justify-between">
                <Text className="text-sm font-medium text-gray-600">
                  {type}
                </Text>
                <Text className="text-sm font-medium text-gray-900">
                  {percentage}%
                </Text>
              </div>
              <ProgressBar
                value={percentage}
                color="blue"
                className="h-2 bg-gray-100"
              />
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default EVStats;
