"use client";

import {
  BarList,
  Card,
  Grid,
  Tab,
  TabGroup,
  TabList,
  TabPanel,
  TabPanels,
  Text,
  Title,
} from "@tremor/react";
import { useEVData } from "../context/EVDataContext";
import { getLocationStats } from "../utils/processData";

const EVLocationMap = () => {
  const { data, loading, error } = useEVData();

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  const locationStats = getLocationStats(data);

  return (
    <div className="mt-4">
      <TabGroup>
        <TabList className="flex space-x-2 border-b border-gray-200">
          <Tab className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-900 ui-selected:text-gray-900 ui-selected:border-b-2 ui-selected:border-blue-500">
            Cities
          </Tab>
          <Tab className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-900 ui-selected:text-gray-900 ui-selected:border-b-2 ui-selected:border-blue-500">
            Counties
          </Tab>
          <Tab className="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-900 ui-selected:text-gray-900 ui-selected:border-b-2 ui-selected:border-blue-500">
            Utilities
          </Tab>
        </TabList>
        <TabPanels>
          <TabPanel>
            <Grid numItemsLg={2} className="mt-6 gap-6">
              <Card className="p-6 bg-white rounded-lg shadow">
                <Title className="text-lg font-medium text-gray-900 mb-4">
                  Top Cities by EV Population
                </Title>
                <BarList
                  data={locationStats.topCities}
                  className="mt-2"
                  valueFormatter={(number: number) =>
                    Intl.NumberFormat("us").format(number).toString()
                  }
                  color="blue"
                />
              </Card>
              <Card className="p-6 bg-white rounded-lg shadow">
                <Title className="text-lg font-medium text-gray-900 mb-4">
                  City Statistics
                </Title>
                <div className="mt-4">
                  <Text className="text-sm text-gray-600">
                    Number of cities with EVs:{" "}
                    <span className="font-medium text-gray-900">
                      {
                        Object.keys(
                          data.reduce((acc, curr) => {
                            acc[curr.City] = true;
                            return acc;
                          }, {} as Record<string, boolean>)
                        ).length
                      }
                    </span>
                  </Text>
                </div>
              </Card>
            </Grid>
          </TabPanel>

          <TabPanel>
            <Grid numItemsLg={2} className="mt-6 gap-6">
              <Card className="p-6 bg-white rounded-lg shadow">
                <Title className="text-lg font-medium text-gray-900 mb-4">
                  Top Counties by EV Population
                </Title>
                <BarList
                  data={locationStats.topCounties}
                  className="mt-2"
                  valueFormatter={(number: number) =>
                    Intl.NumberFormat("us").format(number).toString()
                  }
                  color="indigo"
                />
              </Card>
              <Card className="p-6 bg-white rounded-lg shadow">
                <Title className="text-lg font-medium text-gray-900 mb-4">
                  County Statistics
                </Title>
                <div className="mt-4">
                  <Text className="text-sm text-gray-600">
                    Number of counties with EVs:{" "}
                    <span className="font-medium text-gray-900">
                      {
                        Object.keys(
                          data.reduce((acc, curr) => {
                            acc[curr.County] = true;
                            return acc;
                          }, {} as Record<string, boolean>)
                        ).length
                      }
                    </span>
                  </Text>
                </div>
              </Card>
            </Grid>
          </TabPanel>

          <TabPanel>
            <Grid numItemsLg={2} className="mt-6 gap-6">
              <Card className="p-6 bg-white rounded-lg shadow">
                <Title className="text-lg font-medium text-gray-900 mb-4">
                  Top Electric Utilities
                </Title>
                <BarList
                  data={locationStats.topUtilities}
                  className="mt-2"
                  valueFormatter={(number: number) =>
                    Intl.NumberFormat("us").format(number).toString()
                  }
                  color="emerald"
                />
              </Card>
              <Card className="p-6 bg-white rounded-lg shadow">
                <Title className="text-lg font-medium text-gray-900 mb-4">
                  Utility Statistics
                </Title>
                <div className="mt-4">
                  <Text className="text-sm text-gray-600">
                    Number of utilities serving EVs:{" "}
                    <span className="font-medium text-gray-900">
                      {
                        Object.keys(
                          data.reduce((acc, curr) => {
                            if (curr.ElectricUtility)
                              acc[curr.ElectricUtility] = true;
                            return acc;
                          }, {} as Record<string, boolean>)
                        ).length
                      }
                    </span>
                  </Text>
                </div>
              </Card>
            </Grid>
          </TabPanel>
        </TabPanels>
      </TabGroup>
    </div>
  );
};

export default EVLocationMap;
