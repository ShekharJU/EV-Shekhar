"use client";

import { DonutChart } from "@tremor/react";
import { useEVData } from "../context/EVDataContext";
import { getTopModels } from "../utils/processData";

const EVModelChart = () => {
  const { data, loading, error } = useEVData();

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;

  const chartData = getTopModels(data);

  return (
    <DonutChart
      className="mt-6"
      data={chartData}
      category="value"
      index="model"
      colors={["slate", "violet", "indigo", "rose", "cyan"]}
    />
  );
};

export default EVModelChart;
