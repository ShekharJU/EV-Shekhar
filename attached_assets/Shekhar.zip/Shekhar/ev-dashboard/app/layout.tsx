import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { EVDataProvider } from "./context/EVDataContext";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "EV Population Dashboard",
  description: "Analysis of Electric Vehicle Population in Washington State",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="light">
      <body className={`${inter.className} bg-gray-50 antialiased`}>
        <div className="min-h-screen">
          <nav className="bg-white shadow-sm">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="flex justify-between h-16">
                <div className="flex">
                  <div className="flex-shrink-0 flex items-center">
                    <h1 className="text-xl font-semibold text-gray-900">
                      EV Analytics
                    </h1>
                  </div>
                </div>
              </div>
            </div>
          </nav>
          <EVDataProvider>{children}</EVDataProvider>
        </div>
      </body>
    </html>
  );
}
