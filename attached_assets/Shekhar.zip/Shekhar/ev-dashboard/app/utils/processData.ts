import Papa from "papaparse";

export interface EVData {
  VIN: string;
  County: string;
  City: string;
  State: string;
  PostalCode: string;
  ModelYear: number;
  Make: string;
  Model: string;
  ElectricVehicleType: string;
  ElectricRange: number;
  BaseMSRP: number;
  LegislativeDistrict: number;
  DOLVehicleID: string;
  VehicleLocation: string;
  ElectricUtility: string;
  CensusTract: string;
  CAFVEligibility: string;
}

export const processCSVData = async (file: File): Promise<EVData[]> => {
  return new Promise((resolve, reject) => {
    Papa.parse(file, {
      header: true,
      complete: (results) => {
        resolve(results.data as EVData[]);
      },
      error: (error) => {
        reject(error);
      },
    });
  });
};

export const calculateStats = (data: EVData[]) => {
  const totalEVs = data.length;

  const avgRange = Math.round(
    data.reduce((acc, curr) => acc + Number(curr.ElectricRange), 0) / totalEVs
  );

  const avgMSRP = Math.round(
    data.reduce((acc, curr) => acc + Number(curr.BaseMSRP || 0), 0) / totalEVs
  );

  const makeCount = data.reduce((acc, curr) => {
    acc[curr.Make] = (acc[curr.Make] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const mostCommonMake = Object.entries(makeCount).sort(
    (a, b) => b[1] - a[1]
  )[0][0];

  const yearDistribution = data.reduce((acc, curr) => {
    acc[curr.ModelYear] = (acc[curr.ModelYear] || 0) + 1;
    return acc;
  }, {} as Record<number, number>);

  return {
    totalEVs,
    avgRange,
    avgMSRP,
    mostCommonMake,
    yearDistribution,
  };
};

export const getTopMakes = (data: EVData[], limit = 5) => {
  const makeCount = data.reduce((acc, curr) => {
    acc[curr.Make] = (acc[curr.Make] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return Object.entries(makeCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([make, count]) => ({
      make,
      count,
    }));
};

export const getTopModels = (data: EVData[], limit = 5) => {
  const modelCount = data.reduce((acc, curr) => {
    const key = `${curr.Make} ${curr.Model}`;
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return Object.entries(modelCount)
    .sort((a, b) => b[1] - a[1])
    .slice(0, limit)
    .map(([model, value]) => ({
      model,
      value,
    }));
};

export const getLocationStats = (data: EVData[]) => {
  const countyData = data.reduce((acc, curr) => {
    acc[curr.County] = (acc[curr.County] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const cityData = data.reduce((acc, curr) => {
    acc[curr.City] = (acc[curr.City] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const utilityData = data.reduce((acc, curr) => {
    if (curr.ElectricUtility) {
      acc[curr.ElectricUtility] = (acc[curr.ElectricUtility] || 0) + 1;
    }
    return acc;
  }, {} as Record<string, number>);

  return {
    topCounties: Object.entries(countyData)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([name, value]) => ({ name, value })),

    topCities: Object.entries(cityData)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([name, value]) => ({ name, value })),

    topUtilities: Object.entries(utilityData)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([name, value]) => ({ name, value })),
  };
};

export const getYearlyTrends = (data: EVData[]) => {
  const yearlyData = data.reduce((acc, curr) => {
    const year = curr.ModelYear;
    if (!acc[year]) {
      acc[year] = {
        year,
        count: 0,
        avgRange: 0,
        totalRange: 0,
      };
    }
    acc[year].count++;
    acc[year].totalRange += Number(curr.ElectricRange) || 0;
    return acc;
  }, {} as Record<number, { year: number; count: number; avgRange: number; totalRange: number }>);

  return Object.values(yearlyData)
    .map((year) => ({
      ...year,
      avgRange: Math.round(year.totalRange / year.count),
    }))
    .sort((a, b) => a.year - b.year);
};
